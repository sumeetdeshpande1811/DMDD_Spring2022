 
 
 
 SET SERVEROUTPUT ON
 
 Drop table DEPARTMENT;
 
CREATE TABLE DEPARTMENT(
           dept_id number(5) NOT NULL,
           dept_name varchar(40) NOT NULL,
           dept_location varchar(40) NOT NULL,
           primary key(dept_id)
           );

Select * from department;

drop sequence dept_id;
create sequence dept_id minvalue 1 start with 1 cache 10; 

create or replace Procedure InsertDepartment(id Number,name in varchar,location in varchar) 
IS
x number;
camelname varchar(255);
ex_invalid_name  EXCEPTION; 
ex_invalid_location EXCEPTION;
length_name EXCEPTION;
Begin

 --Select dept_id into x from department where dept_name='CS';

 if  name is null  then
  raise ex_invalid_name ;
ELSIF not regexp_like(name, '^[^1-9]*$') then
 dbms_output.put_line('Invalid Name no number'); 
 elsif location not in ('MA', 'TX', 'IL', 'CA', 'NY', 'NJ', 'NH', 'RH') then 
  raise ex_invalid_location  ;
   elsif Length(name)>20 then 
  raise length_name  ;
  else 
camelname := substr(lower(name),1,1)||substr(replace(initcap(name),' '),2);
     select count(*) 
    into x  
    from department 
    WHERE dept_name =camelname ;
     dbms_output.put_line(x); 


    if x != 0 then  
    update department set dept_location=location where dept_name=camelname;


    else  
     INSERT INTO DEPARTMENT(dept_id,dept_name, dept_location) VALUES (id,camelname,location);
    end if;  

 end if;
 exception
    when no_data_found then
        update department SET dept_location=dept_location where dept_name=dept_name;
    when ex_invalid_name  then
     dbms_output.put_line('Invalid Name');  
     when ex_invalid_location  then
     dbms_output.put_line('Invalid Location'); 
     when length_name  then
      dbms_output.put_line('Length is greater than 20'); 
end InsertDepartment;
/ 

exec InsertDepartment(112,'IS','MA');
exec InsertDepartment(13,'','IL');
exec InsertDepartment(137,'eng mana','MA');

--Enter 6 data 
exec InsertDepartment(dept_id.nextval,'informa tech','MA');
exec InsertDepartment(dept_id.nextval,'software engineering','IL');
exec InsertDepartment(dept_id.nextval,'database management','NJ');
exec InsertDepartment(dept_id.nextval,'data science','TX');
exec InsertDepartment(dept_id.nextval,'art intelligence','RH');
exec InsertDepartment(dept_id.nextval,'industrial eng','TX');

--B. INSERT THE DEPARTMENT IF NAME DOESN'T EXISTS 
exec InsertDepartment(dept_id.nextval,'production eng','TX');
Select * from department;

-- C. UPDATE THE DEPARTMENT LOCATION IF NAME EXISTS
exec InsertDepartment(dept_id.nextval,'production eng','TX');
Select * from department;

-- D RAISE ERROR IF THE DEPARTMENT NAME IS INVALID (NULL, ZERO LENGTH) 
exec InsertDepartment(dept_id.nextval,'','MA');
exec InsertDepartment(dept_id.nextval,NULL,'MA');

-- E RAISE ERROR IF THE DEPARTMENT NAME IS A NUMBER -
exec InsertDepartment(dept_id.nextval,41,'MA');

--F ACCEPTED LOCATIONS SHOULD BE AS BELOW MA, TX, IL, CA, NY, NJ, NH, RH
exec InsertDepartment(dept_id.nextval,'regulatory aff','Mumbai');

--G DEPARTMENT ID SHOULD BE AUTO-GENERATED
exec InsertDepartment(dept_id.nextval,'regulatory aff','NH');
Select * from department;


-- H LENGTH OF THE DEPARTMENT NAME CANNOT BE MORE THAN 20 CHARS
exec InsertDepartment(1154,'aqaqaqaqaqsqsqsssqsqssqsseffffffeffefefefeffefffefef','MA');
Select * from department;
              

--I WHILE INSERTING THE DEPARTMENT NAME CONVERT EVERYTHING TO CAMEL CASE 
exec InsertDepartment(dept_id.nextval,'regulatory aff','TX');
Select * from department;

--J. MAKE SURE DEPARTMENT NAME IS UNIQUE 
exec InsertDepartment(dept_id.nextval,'regulatory aff','NH');
Select * from department;





